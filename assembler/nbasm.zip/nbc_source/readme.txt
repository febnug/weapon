
This is the source to NBC, the NBASM C Compiler found at

  http://www.fysnet.net/newbasic.htm

It is included here because it is a heavily modified version of
Alex's SmallerC compiler found at

  https://github.com/alexfru/SmallerC


If you have any questions about it, please send me an email

   fys [at] fysnet [dot] net

